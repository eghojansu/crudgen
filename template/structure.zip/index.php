<?php

require __DIR__.'/vendor/autoload.php';

$moe = moe\Base::instance();
$dir = 'app/config/';
$ext = '.ini';
foreach ([
    {#config_files#}
] as $config)
    $moe->config($dir.$config.$ext);
$moe->run();
