<?php

namespace app\component;

use app\model\User;
use moe\Instance;

class Auth
{
    public static function attempt($username, $password)
    {
        $model = User::instance()
            ->findByUsernamePassword($username, self::password($password))
            ->read(1);
        ($dry = $model->dry()) || self::login($model->cast(), true);

        return !$dry;
    }

    public static function update($data)
    {
        $model = User::instance()->findByPK(self::id())->read(1);
        $model->copyfrom('POST', function($data){
            return $data;
        });
        $data['password'] || $model->password = null;
        $saved = $model->save();
        !$saved || self::login($model->cast(), true);

        return $saved;
    }

    public static function id()
    {
        return self::data('id_user');
    }

    public static function password($password)
    {
        return $password;
    }

    public static function isLogged()
    {
        return (bool) Instance::get('SESSION.login');
    }

    public static function isAdmin()
    {
        return (bool) Instance::get('SESSION.admin');
    }

    public static function data($what = null)
    {
        return Instance::get('SESSION.data'.($what?'.'.$what:''));
    }

    public static function login($data, $admin)
    {
        Instance::mset(array(
            'SESSION.login'=>true,
            'SESSION.admin'=>$admin,
            'SESSION.data'=>$data,
            ));

        return true;
    }

    public static function logout($route = '@logout')
    {
        Instance::clear('SESSION');
        !$route || Instance::reroute($route);

        return true;
    }
}
