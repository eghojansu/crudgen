<?php

namespace app\component;

abstract class AbstractAdmin
{
    public function afterroute($moe)
    {
        $moe->set('rendertime', number_format(microtime(true)-$moe->get('TIME'), 7));
    }

    public function __construct($moe)
    {
        // do something
    }
}
