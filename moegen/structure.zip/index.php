<?php

require __DIR__.'/vendor/autoload.php';

$moe = moe\Base::instance();
$dir = '{#path_ini#}';
$ext = '.ini';
foreach ([
    {#config_files#}
] as $config)
    $moe->config($dir.$config.$ext);
$moe->run();
